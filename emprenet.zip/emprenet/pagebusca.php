<html xmlns="http://www.w3.org/1999/xhtml" lang="pt-br" xml:lang="pt-br">
	  <head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	  <title>EMPRENET</title>
</head>
</head>

<body> 	
	 <style type="text/css">	

*{
	background-image: url("16.jpg");
}



</style>

<?php
include('conexao.php');

	
$sql_code= " SELECT * FROM usuarios";
$sql_query = $mysqli->query($sql_code) or die ($mysqli->error);
$linha=$sql_query->fetch_assoc();
?>



<h1>Busca Emprenet</h1>	
<p class=espaco></p>
<table border=1 cellpadding=10>	
	<tr class="titulo">
		<td>Nome</td>
		<td>Email</td>
		<td>Logradouro</td>
		<td>Bairro</td>
		<td>Cidade</td>
		<td>Email</td>
		<td>Celular</td>
		<td>Usuário</td>
</tr>
<?php
do{
?>

<tr>

<td><?php echo $linha['nome'];?></td>
<td><?php echo $linha['email'];?></td>
<td><?php echo $linha['logradouro'];?></td>
<td><?php echo $linha['bairro'];?></td>
<td><?php echo $linha['cidade'];?></td>
<td><?php echo $linha['email'];?></td>
<td><?php echo $linha['celular'];?></td>
<td><?php echo $linha['usuario'];?></td>
<td>
<a href="detalhes.php">Detalhes de Contrato</a>
	</td>
	</tr>

<?php } while($linha=$sql_query->fetch_assoc()); ?>
</table>


</body>
</html>