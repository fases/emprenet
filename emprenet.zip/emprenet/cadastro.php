  <html lang="pt-br">
  <head>
<title>p�gina de cadastro</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body> 
 	<style type="text/css">

body{
background-image:url("15.jpg");
}

h1{
color:#1E90FF;	
	text-align:center;	
	font: bold 50px Sans-Serif;
text-shadow:1px 3px 1px white;
}

.input-div{
display: inline-block;
margin:20px;
padding:2px;
border-radius:3px;
font:bold 12px sans-serif;
color:#FAEBD7;
}

.input-div input{
width:300px;
height:25px;
padding-left:5px;
font:normal 12px sans-serif;
color:black;
border-radius:5px;
border:1px solid #bfc4c6	;
outline: none; <!-- desabilitar bordas automaticas -->
}



#cadastrar{
height:50px;
width:100px;
background-color:#18F7CF;
font: bold 13px sans-serif;
margin-left: 500px;
}


input[type=descricao]{
   width: 1000px;
   height: 100px;
font:normal 12px sans-serif;
color:black;
border-radius:5px;
border:1px solid #bfc4c6	;
outline: none;
display: inline-block;
margin:20px;
padding:2px;
border-radius:3px;
font:bold 12px sans-serif;
}


</style>
 	</head>


<h1>P�gina de Cadastro</h1> 
<form required name="signup" method="post" action="cadastrando.php"> 

<div class="input-div" id="nome">
	Nome Completo:<br/> <input required type="text" name="nome" />
</div>


<div class="input-div" id="email">
	Email: <br/><input  required type="email" name="email" />
</div>

<div class="input-div" id="confirmaremail" >
	Confirmar Email:<br/> <input required type="email" name="confirmaremail" />
</div>

<div class="input-div" id="logradouro">
	Logradouro:<br/> <input required type="text" name="logradouro" />
</div>


<div class="input-div" id="bairro">
	Bairro:<br/> <input required type="text" name="bairro" />
</div>


<div class="input-div" id="cidade">
	Cidade:<br/> <input required type="text" name="cidade" />
</div>


<div class="input-div" id="uf">
	UF:<br/> <input required type="text" name="uf" />
</div>


<div class="input-div" id="cpf">
	CPF: <br/><input required type="text" name="cpf" />
</div>


<div class="input-div" id="celular">
	Celular: <br/><input required type="text" name="celular" />
</div>

<div class="input-div" id="usuario">
	Usu�rio:<br/> <input required type="text" name="usuario" />
</div>

<div class="input-div" id="senha">
	Senha:<br/> <input required type="password" name="senha" />
</div>

<div class="input-div" id="confirmarsenha">
	Confirmar Senha: <br/><input required type="password" name="confirmarsenha" />
</div>

<div class="input-div" id="descricao">
	Descri��o (Se n�o for diarista, apenas escrever no campo: "n�o sou uma diarista"): <br/><input required type="descricao" name="descricao" 
	placeholder="Descreva como fazer para contat�-la para que possam lhe contratar,
 descreva suas fun��es, seus hor�rios e pre�os, e tudo que voc� acha necess�rio para ser contratada(o)." />
</div>

<input id="cadastrar" type="submit" value="Cadastrar">


</div>
</form>
</body>
</html>