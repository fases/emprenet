<html xmlns="http://www.w3.org/1999/xhtml" lang="pt-br" xml:lang="pt-br">
	  <head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	  <title>EMPRENET</title>
</head>
<body> 	

	  
	   <style type="text/css">	

*{
	background-image: url("16.jpg");
}

.b1 a:link{
background: yellow;
text-decoration: none;
}

.b1{
	color:yellow;
	padding:1px 20px;

font:normal 42px sans-serif;
}

#busca{

margin-left: 300px;
margin-top: 200px;
}

#meusanununcios{
	margin-left: 500px;
margin-top: -50px;
}

#inseriranuncio{
	margin-left: 500px;
margin-top: 50px;
}

#meuperfil{
	margin-left: 300px;
margin-top: -50px;
}

	   </style>
</head>

<div class="b1" id="busca">
<a href="pagebusca.php" style="color:#007FFF">Buscar</a>
</div>


<div class="b1" id="meusanununcios">
<a href="meusanuncios.php" style="color:#007FFF">Meus Anúncios</a>
</div>

<div class="b1" id="inseriranuncio">
<a href="inseriranuncio.php" style="color:#007FFF">Inserir Anúncio</a>
</div>

<div class="b1" id="meuperfil">
<a href="meuperfil.php" style="color:#007FFF">Meu Perfil</a>
</div>




</body>
</html>